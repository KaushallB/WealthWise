# HTML check

The database used for HTML support tests is based on [can I email](https://www.caniemail.com/).

The `caniemail-data.json` file used to determine client support is copied from the [API](https://www.caniemail.com/api/data.json)
