package main

import "github.com/axllent/mailpit/sendmail/cmd"

func main() {
	cmd.Run()
}
